<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/footersection', function () {
    return view('footer');
});

Route::get('/aboutus', function () {
    return view('about');
});

Route::get('/documentation',function(){
    return view('documentation');
});

Route::get('/laravel-install',function(){
    return view('laravel-install');
});

Route::get('login','EmployeeController@loginpage');

Route::get('registration','EmployeeController@index');
Route::post('/save', 'EmployeeController@create');

Route::get('/show', 'EmployeeController@showAll');
Route::get('/delete/{id}','EmployeeController@delete');
Route::get('/edit/{id}','EmployeeController@edit');
Route::post('/update/{id}','EmployeeController@update');

Route::get('/search','EmployeeController@searchBy');
