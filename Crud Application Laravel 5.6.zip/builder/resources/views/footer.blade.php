<div class="container-fluid" style="background-color:#242729;height:50px;border-top:3px solid #F48024; 
position:fixed;left: 0;bottom: 0;width: 100%;color: white;text-align: center;">
            
                <div class="col-sm-12" style="margin-top:15px">
                    <p style="text-align:center;color:#fff">Copyright © 2013<a target="_blank" href="https://www.sssit.org" title="SSSIT.ORG"> SSS IT Pvt LTD</a> All Rights Reserved.</p>
                </div>
               
            </div>
</div>
