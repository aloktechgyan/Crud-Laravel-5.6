<!DOCTYPE html>
<html lang="en">
<head>
  <title>About us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<!--========================================-->
@include('index');  <br><br><br><br><br>
<!--========================================-->
<div class="container">
  <form class="form-inline" action="search">
  <div class="form-group">
    <label>Search Here:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
    </div>
    
    <div class="form-group">
      <label for="Searchbyid">Search By Id: </label>
      <input type="text" class="form-control" placeholder="Search By Id" name="email">
    </div>
    <div class="form-group">
      <label for="pwd">Search By Name:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Serach By Name" name="pwd">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div><hr>
<br><br><br><br>

@include('footer');
</body>
</html>
