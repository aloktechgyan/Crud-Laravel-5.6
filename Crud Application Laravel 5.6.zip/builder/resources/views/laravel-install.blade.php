i<div class="panel panel-default">
    <div class="panel-heading">How to install Laravel 5.6</div>
    <div class="panel-body">
Panel ContentTesting is one of those practices that sounds incredibly simple, yet, in practice, it can take years to master. If there is such thing as a short-cut, working your way through skill will be your best bet.
Testing is one of those practices that sounds incredibly simple, yet, in practice, it can take years to master. If there is such thing as a short-cut, working your way through skill will be your best bet.
SHARE THTesting is one of those practices that sounds incredibly simple, yet, in practice, it can take years to master. If there is such thing as a short-cut, working your way through skill will be your best bet.
SHARE THTesting is one of those practices that sounds incredibly simple, yet, in practice, it can take years to master. If there is such thing as a short-cut, working your way through skill will be your best bet.
SHARE THTesting is one of those practices that sounds incredibly simple, yet, in practice, it can take years to master. If there is such thing as a short-cut, working your way through skill will be your best bet.
SHARE THTesting is one of those practices that sounds incredibly simple, yet, in practice, it can take years to master. If there is such thing as a short-cut, working your way through skill will be your best bet.
SHARE THTesting is one of those practices that sounds incredibly simple, yet, in practice, it can take years to master. If there is such thing as a short-cut, working your way through skill will be your best bet.
SHARE TH
SHARE TH</div>
  </div>
