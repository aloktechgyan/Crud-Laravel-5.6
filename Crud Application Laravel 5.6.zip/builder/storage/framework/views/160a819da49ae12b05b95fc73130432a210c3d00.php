<!DOCTYPE html>
<html lang="en">
<head>
  <title>Registration form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<!--========================================-->
  <?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;  
<!--========================================-->
<div class="container-fluid"><br><br>
<div class="col-sm-8" style="background-color:#fff;height:900px"><br><br>
<!--========================================-->
<div id='content'>
      <!-- The data-tab attribute will be used by the tab that is clicked to identify the content to show -->
      <div class='tab' data-tab='a' style='display: none;border:1px dotted gray;border-radius:2px'>
        <h3 style="background-color:#ff980038;padding:10px;margin-top:-1px;">Install Laravel in Windows</h3>  
        <p>Tabs are essentially elements that are given a specific CSS class so that they 
        can be easily grouped or targeted. The buttons that coorespond to your tabs 
         have some type of attribute that forms a relationship between the tab and it's content
         (so that it knows what to show when it is clicked).
        </p>
      </div>
      <div class='tab' data-tab='b' style='display: none;border:1px dotted gray'>
        <h3 style="background-color:#ff980038;padding:10px;margin-top:-1px">Insatall Laravel in Linux</h3>  
        <p>that it knows what to show when it is clicked Tabs are essentially elements that are given a specific CSS class so that they 
        can be easily grouped or targeted. The buttons that coorespond to your tabs 
         have some type of attribute that forms a relationship between the tab and it's content
         (so that it knows what to show when it is click.
         <!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><pre style="margin: 0; line-height: 125%"><span style="color: #557799">&lt;?php</span>

<span style="color: #008800; font-weight: bold">use</span> Illuminate\Support\Facades\Schema;
<span style="color: #008800; font-weight: bold">use</span> Illuminate\Database\Schema\Blueprint;
<span style="color: #008800; font-weight: bold">use</span> Illuminate\Database\Migrations\Migration;
<span style="color: #008800; font-weight: bold">class</span> <span style="color: #BB0066; font-weight: bold">CreateFlightsTable</span> <span style="color: #008800; font-weight: bold">extends</span> Migration
{
    <span style="color: #DD4422">/**</span>
<span style="color: #DD4422">     * Run the migrations.</span>
<span style="color: #DD4422">     *</span>
<span style="color: #DD4422">     * @return  void</span>
<span style="color: #DD4422">     */</span>
    <span style="color: #008800; font-weight: bold">public</span> <span style="color: #008800; font-weight: bold">function</span> <span style="color: #0066BB; font-weight: bold">up</span>()
    {
        Schema<span style="color: #333333">::</span><span style="color: #0000CC">create</span>(<span style="background-color: #fff0f0">&#39;flights&#39;</span>, <span style="color: #008800; font-weight: bold">function</span> (Blueprint <span style="color: #996633">$table</span>) {
            <span style="color: #996633">$table</span><span style="color: #333333">-&gt;</span><span style="color: #0000CC">increments</span>(<span style="background-color: #fff0f0">&#39;id&#39;</span>);
            <span style="color: #996633">$table</span><span style="color: #333333">-&gt;</span><span style="color: #0000CC">string</span>(<span style="background-color: #fff0f0">&#39;name&#39;</span>);
            <span style="color: #996633">$table</span><span style="color: #333333">-&gt;</span><span style="color: #0000CC">string</span>(<span style="background-color: #fff0f0">&#39;airline&#39;</span>);
            <span style="color: #996633">$table</span><span style="color: #333333">-&gt;</span><span style="color: #0000CC">timestamps</span>();
        });
    }
<span style="color: #DD4422">/**</span>
<span style="color: #DD4422">     * Reverse the migrations.</span>
<span style="color: #DD4422">     *</span>
<span style="color: #DD4422">     * @return  void</span>
<span style="color: #DD4422">     */</span>
    <span style="color: #008800; font-weight: bold">public</span> <span style="color: #008800; font-weight: bold">function</span> <span style="color: #0066BB; font-weight: bold">down</span>()
    {
        Schema<span style="color: #333333">::</span><span style="color: #0000CC">drop</span>(<span style="background-color: #fff0f0">&#39;flights&#39;</span>);
    }
}
</pre></div>

      </div>
      <div class='tab' data-tab='c' style='display: none;border:1px dotted gray'>
        <h3 style="background-color:#ff980038;padding:10px;margin-top:-1px">Laravel Important Command</h3>  
        <p>Tabs are essentially elements that are given a specific CSS class so that they 
        can be easily grouped or targeted. The buttons that coorespond to your tabs 
         have some type of attribute that forms a relationship between the tab and it's content
         (so that it knows what to show when it is clicked).
      </div>
      <div class='tab' data-tab='d' style='display: none;border:1px dotted gray'>
        <h3 style="background-color:#ff980038;padding:10px;margin-top:-1px"> Install Wordpress</h3>  
        <p> that it knows what to show when it is clickedTabs are essentially elements that are given a specific CSS class so that they 
        can be easily grouped or targeted. The buttons that coorespond to your tabs 
         have some type of attribute that forms a relationship between the tab and it's content
         (so that it knows what to show when it is clicked).
      </div>
</div>

<!--========================================-->

</div>

<div class="col-sm-4" style="background-color:#fff;height:900px"><br><br>
  <div class="list-group">
    <a href="#" class="list-group-item active">Laravel Latest Tutorial 5.6</a>
    <a class='open-tab list-group-item fa fa-hand-o-right' href="#" data-tab='a'> Install Laravel in Windows</a>
    <a class='open-tab list-group-item fa fa-hand-o-right' href="#" data-tab='b'> Insatall Laravel in Linux</a>
    <a class='open-tab list-group-item fa fa-hand-o-right' href="#" data-tab='c'> Laravel Important Command</a>
    <a class='open-tab list-group-item fa fa-hand-o-right' href="#" data-tab='d'> Install Wordpress</a>
  </div>
  <div class="list-group">
   <a href="#" class="list-group-item active">Important Questions</a>
   <a href="#" class="list-group-item fa fa-hand-o-right"> Java(80)</a>
   <a href="#" class="list-group-item fa fa-hand-o-right"> Laravel(70)</a>
   <a href="#" class="list-group-item fa fa-hand-o-right"> Datapbase(200)</a>
  <a href="#" class="list-group-item fa fa-hand-o-right"> PHP(50)</a>
  </div>
 
  <div class="list-group">
    <a href="#" class="list-group-item active"> Wordpress Tutorial</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Install Laravel in Windows</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Insatall Laravel in Linux</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Second item</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Third item</a>
  </div>
  <div class="list-group">
    <a href="#" class="list-group-item active">Mysql  Database</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Install Laravel in Windows</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Insatall Laravel in Linux</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Second item</a>
    <a href="#" class="list-group-item fa fa-hand-o-right"> Third item</a>
  </div>

  </div>
  </div>
</div>


</div>
<!-- jQuery code to tie things all together -->
<script type='text/javascript'>
    $(function(){
        // When an open tab item from your menu is clicked
        $(".open-tab").click(function(){
            // Hide any of the content tabs
            $(".tab").hide();
            // Show your active tab (read from your data attribute)
            $('[data-tab ="' + $(this).data('tab') + '"]').show();
            // Optional: Highlight the selected tab
            $('li.active').removeClass('active');
            $(this).closest('li').addClass('active');
        });
    });
 </script>
 <br><br><br><br>
 <!--========================================-->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
<!--========================================-->
</body>
</html>
