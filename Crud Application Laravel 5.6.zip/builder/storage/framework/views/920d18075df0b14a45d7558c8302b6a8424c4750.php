<!DOCTYPE html>
<html lang="en">
<head>
  <title>About us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<!--========================================-->
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;  <br><br>
<!--========================================-->

     <h1 class="text-center">About us</h1>      
    <p>The Laravel framework has a few system requirements. Of course, all of these requirements are satisfied by the Laravel Homestead virtual machine, so it's highly recommended that you use Homestead as your local Laravel development environment.
</p>
<!--========================================-->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;  <br><br>
<!--========================================-->

</body>
</html>
