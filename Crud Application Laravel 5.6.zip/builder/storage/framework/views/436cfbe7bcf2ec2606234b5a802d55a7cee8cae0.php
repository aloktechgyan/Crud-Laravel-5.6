<!DOCTYPE html>
<html lang="en">
<head>
  <title>Laravel 5.6</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

<link href="<?php echo e(asset('css/css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>
<body style="background-color:#fafafb">
<nav class="navbar navbar-default navbar-fixed-top" style="font-size:17px;border-bottom:3px solid #F48024;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Laravel 5.6</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="/">Home</a></li>
        <li><a href="<?php echo e(url('/aboutus')); ?>">About us</a></li>
        <li><a href="<?php echo e(url('/registration')); ?>">Create</a></li>
        <li><a href="<?php echo e(url('/show')); ?>">Show</a></li>
        <li><a href="<?php echo e(url('/search')); ?>">Search</a></li>
        <li><a href="<?php echo e(url('/documentation')); ?>">Documentation</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right nav nav-tabs">
        <!-- <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li> -->
        <li><a href="<?php echo e(url('/login')); ?>"><button type="button" class="btn btn-primary btn-xs"> Login</button></a></li>
      </ul>
    </div>
  </div>
</nav>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
</body>
</html>
